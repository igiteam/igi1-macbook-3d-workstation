// Email updates sign-up (Worker: deploy/worker/src/updates.js). Every form.upd on a page posts its address; the Worker mails one link to confirm and nothing else.
document.querySelectorAll('form.upd').forEach((f) => {
  const msg = f.querySelector('.msg'), btn = f.querySelector('button');
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); msg.textContent = '';
    const email = f.elements.email, bad = (t) => { msg.textContent = t; email.setAttribute('aria-invalid', 'true'); };      // the message is the field's description (aria-describedby in the markup)
    email.removeAttribute('aria-invalid');
    if (!email.value.trim() || !email.checkValidity()) { bad('That email address does not look right.'); email.focus(); return; }
    btn.disabled = true;
    const r = await fetch('/api/updates/subscribe', { method: 'POST', headers: { 'X-Nolf': '1', 'Content-Type': 'application/json' }, body: JSON.stringify({ email: email.value.trim(), website: f.elements.website.value }) }).catch(() => null);
    btn.disabled = false;
    if (r?.status === 202) { msg.textContent = 'Check your inbox: one email to confirm.'; email.value = ''; }
    else bad(r ? (await r.json().catch(() => ({}))).error || 'Something went wrong. Try again later.' : 'The network is down. Try again in a moment.');
  });
});
// signed-in visitors: assets/notices.js
window.nolfNoticesLoad = () => import('/assets/notices.js').catch(() => {});
if (/(^|;\s*)nolf_in=1/.test(document.cookie)) window.nolfNoticesLoad();
