// Site analytics (owner, 2026-10-10): Google Analytics 4 and Cloudflare Web Analytics, on playnolf.com only; tests and local copies send nothing.
// Pages and the game (web/game/track.js) call nolfTrack(name, params); every call is also kept in window.nolfEvents, which the tests read.
// Both services load after the page has loaded, so neither the first paint nor the game's download waits for them. What this records on its own:
// play_click (a link into the game, with the level or how it starts), panel_open (a technical file of the making-of article), video_start, music_play.
(() => {
  // GA: the GA4 measurement ID (property 558222292, Brightwork's GA account). CF: a Cloudflare Web Analytics token; '' because Cloudflare adds its own beacon to every
  // HTML page of the zone (Web Analytics automatic setup, site ee6a1689..., owner 2026-10-10): a second one here would count every visit twice.
  const GA = 'G-NX957MYQDK', CF = '';
  const live = location.hostname === 'playnolf.com';
  window.nolfEvents = [];
  window.dataLayer = window.dataLayer || [];
  function gtag() { dataLayer.push(arguments); }
  if (live && GA) { gtag('js', new Date()); gtag('config', GA); }
  window.nolfTrack = (name, params = {}) => { nolfEvents.push([name, params]); if (live && GA) gtag('event', name, params); };

  // links into the game, from anywhere on the site
  addEventListener('click', (e) => {
    const a = e.target.closest?.('a[href^="/play/"]');
    if (a) {
      const q = new URL(a.href).searchParams, w = q.get('world');
      nolfTrack('play_click', { level: w ? w.split('/').pop().toUpperCase() : q.get('continue') ? 'continue' : 'new_game', from: a.id || a.closest('[id]')?.id || '' });
    }
    const f = e.target.closest?.('[data-file]');
    if (f) nolfTrack('panel_open', { panel: f.dataset.file });
  }, true);
  // the first play of each video and of the music on a page (not the muted, looping reel the landing page plays by itself)
  const seen = new Set();
  addEventListener('play', (e) => {
    if (e.target.muted && e.target.loop) return;
    const m = e.target, name = (m.currentSrc || m.src || '').split('/').pop().replace(/-[0-9a-f]{8}(?=\.)/, '');
    if (!name || seen.has(name)) return;
    seen.add(name);
    nolfTrack(m.tagName === 'AUDIO' ? 'music_play' : 'video_start', { name });
  }, true);

  if (!live) return;
  const start = () => {
    if (GA) { const s = document.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA; document.head.append(s); }
    if (CF) { const s = document.createElement('script'); s.defer = true; s.src = 'https://static.cloudflareinsights.com/beacon.min.js'; s.dataset.cfBeacon = JSON.stringify({ token: CF }); document.head.append(s); }
  };
  if (document.readyState === 'complete') setTimeout(start); else addEventListener('load', () => setTimeout(start), { once: true });
})();
