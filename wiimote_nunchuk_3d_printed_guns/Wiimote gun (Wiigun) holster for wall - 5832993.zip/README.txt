Wiimote gun (Wiigun) holster for wall by Martbob on Thingiverse: https://www.thingiverse.com/thing:5832993

Summary:
I saw an other holder like this one but my gun didn't fit. So here is a wider one.